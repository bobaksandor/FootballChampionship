<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <header>
        <nav class="bg-gray-200 px-4 py-2 ">
            <div class="flex justify-between">
              <div class="flex items-center space-x-4 text-3xl">
                <a href="/" class="text-gray-800 font-bold text-lg"><img class="w-10 h-10" src="https://cdn.pixabay.com/photo/2013/07/13/10/51/football-157930__340.png" alt=""></a>
                <ul class="flex space-x-4">
                  <li><a href="<?php echo e(route('games.index')); ?>" class="text-blue-500 hover:text-blue-700">Mérkőzések</a></li>
                  <li><a href="<?php echo e(route('teams.index')); ?>" class="text-blue-500 hover:text-blue-700">Csapatok</a></li>
                  <li><a href="<?php echo e(route('tables.index')); ?>" class="text-blue-500 hover:text-blue-700">Tabella</a></li>
                  <li><a href="" class="text-blue-500 hover:text-blue-700">Kedvenceim</a></li>
                </ul>
              </div>
              <div class="flex items-center space-x-4">
                
                
                <?php if(auth()->guard()->guest()): ?>
                    <a class="text-gray-800 font-bold" href="<?php echo e(route('login')); ?>">Login</a>
                    <a href="" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700">Sign up</a>
                <?php else: ?>
                    <?php if(auth()->guard()->check()): ?>
                        <p class="mr-7">Szia, <?php echo e(Auth::user() -> name); ?>!</p>
                    
                    <?php endif; ?>
                    <a class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                        Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    
                <?php endif; ?>
              </div>
            </div>
          </nav>
          
          
    </header>
    <body class="font-sans text-gray-900 antialiased bg-gray-200">
        <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-200">
            

            <div class="w-full mt-6 px-6 py-4 bg-gray-200 shadow-md overflow-hidden sm:rounded-lg">
                <?php echo e($slot); ?>

            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\A Suli\Szerveroldali\football_championship\resources\views/layouts/guest.blade.php ENDPATH**/ ?>