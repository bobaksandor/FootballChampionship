<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bg-gray-200' => true]); ?>
    <?php if(auth()->user() != null && auth()->user()->is_admin): ?>
        <a class="ml-10 inline-block p-2 bg-sky-700 hover:bg-sky-900 text-white text-center" href="<?php echo e(route('games.create')); ?>">Új mérkőzés hozzáadása</a>
    <?php endif; ?>
    
    <div class="mx-auto flex flex-col bg-gray-200">
    <h1 class="text-4xl font-bold mb-4">Élő meccsek</h1>
      <ul class="border border-gray-300 rounded-md divide-y divide-gray-300 text-center">
            <?php $__empty_1 = true; $__currentLoopData = $live; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('games.show', ['game' => $game->id])); ?>">
                <li class="flex flex-col text-3xl text-center justify-center"> 
                    <div class="flex flex-row justify-center">
                        <?php if($game->homeTeam->image == "placeholder"): ?>
                            <img class="w-7 h-7" src="https://thumbs.dreamstime.com/b/vector-logo-template-soccer-ball-color-91657652.jpg" alt="">
                        <?php else: ?>
                            <img class="w-7 h-7" src="<?php echo e(asset('storage/images/' . $game->homeTeam->image)); ?>" alt="">
                        <?php endif; ?>
                        <?php echo e($game->homeTeam->name); ?> 
                        <?php if($game->start < now()): ?>
                            <?php echo e($results->where('game_id', $game->id)->first()['homeScore']); ?>

                        <?php endif; ?> -
                    
                        <?php if($game->start < now()): ?>
                            <?php echo e($results->where('game_id', $game->id)->first()['awayScore']); ?>

                        <?php endif; ?>
                        <?php echo e($game->awayTeam->name); ?>

                        <?php if($game->awayTeam->image == "placeholder"): ?>
                            <img class="w-7 h-7" src="https://thumbs.dreamstime.com/b/vector-logo-template-soccer-ball-color-91657652.jpg" alt="">
                        <?php else: ?>
                            <img class="w-7 h-7" src="<?php echo e(asset('storage/images/' . $game->awayTeam->image)); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <br>
                    <p class=""><?php echo e($game->start); ?></p>
                    <?php if(auth()->user() != null && auth()->user()->is_admin): ?>
                        <div class="flex flex-row justify-center mt-4">
                            <a class="ml-10 inline-block p-2 bg-sky-700 hover:bg-sky-900 text-white" href="<?php echo e(route('games.openEdit', ['game' => $game->id])); ?>">Módosít</a>
                                    
                            <form action="<?php echo e(route('games.destroy', ['game' => $game->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="ml-10 inline-block p-2 bg-red-700 hover:bg-red-900 text-white">Törlés</button>
                            </form>
                        </div>
                                
                    <?php endif; ?>
                    <hr class="border-1 border-gray-500 my-4">
                </li>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                Nincsenek meccsek.
            <?php endif; ?>
      </ul>
      <h1 class="text-4xl font-bold mb-4">Összes meccs</h1>
      <ul class="border border-gray-300 rounded-md divide-y divide-gray-300 text-center">
            <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('games.show', ['game' => $game->id])); ?>">
                    <li class="flex flex-col text-3xl text-center justify-center"> 
                        <div class="flex flex-row justify-center">
                            <?php if($game->homeTeam->image == "placeholder"): ?>
                                <img class="w-7 h-7" src="https://thumbs.dreamstime.com/b/vector-logo-template-soccer-ball-color-91657652.jpg" alt="">
                            <?php else: ?>
                                <img class="w-7 h-7" src="<?php echo e(asset('storage/images/' . $game->homeTeam->image)); ?>" alt="">
                            <?php endif; ?>
                            <?php echo e($game->homeTeam->name); ?> 
                            <?php if($game->start < now()): ?>
                                <?php echo e($results->where('game_id', $game->id)->first()['homeScore']); ?>

                            <?php endif; ?> -
                        
                            <?php if($game->start < now()): ?>
                                <?php echo e($results->where('game_id', $game->id)->first()['awayScore']); ?>

                            <?php endif; ?>
                            <?php echo e($game->awayTeam->name); ?>

                            <?php if($game->awayTeam->image == "placeholder"): ?>
                                <img class="w-7 h-7" src="https://thumbs.dreamstime.com/b/vector-logo-template-soccer-ball-color-91657652.jpg" alt="">
                            <?php else: ?>
                                <img class="w-7 h-7" src="<?php echo e(asset('storage/images/' . $game->awayTeam->image)); ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <br>
                        <p class=""><?php echo e($game->start); ?></p>
                        
                        <?php if(auth()->user() != null && auth()->user()->is_admin): ?>
                        <div class="flex flex-row justify-center mt-4">
                            <a class="ml-10 inline-block p-2 bg-sky-700 hover:bg-sky-900 text-white" href="<?php echo e(route('games.openEdit', ['game' => $game->id])); ?>">Módosít</a>
                                    
                            <form action="<?php echo e(route('games.destroy', ['game' => $game->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="ml-10 inline-block p-2 bg-red-700 hover:bg-red-900 text-white">Törlés</button>
                            </form>
                        </div>
                                
                    <?php endif; ?>
                        <hr class="border-1 border-gray-500 my-4">
                    </li>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                Nincsenek meccsek.
            <?php endif; ?>
      </ul>
    </div>
    <?php echo e($games->links()); ?>

   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
  <?php /**PATH C:\A Suli\Szerveroldali\football_championship\resources\views/games/index.blade.php ENDPATH**/ ?>