<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bg-gray-200' => true]); ?>
    <?php if(auth()->user() != null && auth()->user()->is_admin): ?>
        <a class="ml-10 inline-block p-2 bg-sky-700 hover:bg-sky-900 text-white text-center" href="<?php echo e(route('teams.create')); ?>">Új csapat hozzáadása</a>
    <?php endif; ?>
    <?php $__empty_1 = true; $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('teams.show', ['team' => $team->id])); ?>">
                <li class="flex flex-col text-3xl text-center justify-center"> 
                    <div class="flex flex-row justify-center">
                        <?php if($team->image == "placeholder"): ?>
                            <img class="w-10 h-10 mr-7" src="https://thumbs.dreamstime.com/b/vector-logo-template-soccer-ball-color-91657652.jpg" alt="">  
                        <?php else: ?>
                            <img class="w-10 h-10 mr-7" src="<?php echo e(asset('storage/images/' . $team->image)); ?>" alt="">    
                        <?php endif; ?>
                        
                        <p class="ml-7 mr-7"><?php echo e($team->name); ?></p> 
                        <p class="ml-7"><?php echo e($team->shortname); ?></p>
                        
                    </div>
                    <div class="flex justify-center mt-5">
                        <a class="ml-10 inline-block p-2 bg-sky-700 hover:bg-sky-900 text-white wid w-1/5 justify-center" href="<?php echo e(route('teams.openEdit', ['team' => $team->id])); ?>">Módosít</a>
                    </div>
                    <br>
                    
                    <hr class="border-1 border-gray-500 my-4">
                </li>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            Nincsenek csapatok.
        <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\A Suli\Szerveroldali\football_championship\resources\views/teams/index.blade.php ENDPATH**/ ?>