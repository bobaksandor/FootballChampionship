<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(auth()->user() != null && auth()->user()->is_admin && $game->start < now() && !$game->finished): ?>
        <div class="text-center text-6xl">                      
            <form action="<?php echo e(route('games.update', ['game' => $game->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="start" value="<?php echo e($game->start); ?>">
                <input type="hidden" name="finished" value="<?php echo e(true); ?>">
                <input type="hidden" name="home_team_id" value="<?php echo e($game->homeTeam); ?>">
                <input type="hidden" name="away_team_id" value="<?php echo e($game->awayTeam); ?>">
                <input type="hidden" name="which" value="lezar">
                <button type="submit" class="ml-10 inline-block p-2 bg-sky-700 hover:bg-sky-900 text-white">Befejez</button>
            </form>
        </div>
    <?php endif; ?>

    <div class="mx-auto flex flex-col bg-gray-200">
        <h1 class="mb-4">Adatok</h1>
        <div class="mb-8">
            <div class=" flex flex-row justify-center text-5xl">
                <?php if($game->homeTeam->image == "placeholder"): ?>
                    <img class="w-11 h-11" src="https://thumbs.dreamstime.com/b/vector-logo-template-soccer-ball-color-91657652.jpg" alt="">
                <?php else: ?>
                    <img class="w-11 h-11" src="<?php echo e(asset('storage/images/' . $game->homeTeam->image)); ?>" alt="">
                <?php endif; ?>
                <?php echo e($game->homeTeam->name); ?> 
                <?php if($game->start < now()): ?>
                    <?php echo e($results->where('game_id', $game->id)->first()['homeScore']); ?>

                <?php endif; ?> -
            
                <?php if($game->start < now()): ?>
                    <?php echo e($results->where('game_id', $game->id)->first()['awayScore']); ?>

                <?php endif; ?>
                <?php echo e($game->awayTeam->name); ?>

                <?php if($game->awayTeam->image == "placeholder"): ?>
                    <img class="w-11 h-11" src="https://thumbs.dreamstime.com/b/vector-logo-template-soccer-ball-color-91657652.jpg" alt="">
                <?php else: ?>
                    <img class="w-11 h-11" src="<?php echo e(asset('storage/images/' . $game->awayTeam->image)); ?>" alt="">
                <?php endif; ?>
            </div>
            <p class="mt-5 text-3xl text-center"><?php echo e($game->start); ?></p>
        </div>
        <h1 class="mb-4">Események</h1>
        <?php if($game->start < now()): ?>
            <ul class="border border-gray-300 rounded-md divide-y divide-gray-300 text-center">
                <?php $__currentLoopData = $game->events->sortBy('minute'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex flex-col text-3xl text-center justify-center mg mb-4 mt-4"> 
                        <div class="flex flex-row justify-center">
                            <?php echo e($players->firstWhere('id', $event->player_id)->team->name); ?> |
                            <?php echo e($event->type); ?> |
                            <?php echo e($event->minute); ?>. perc |
                            <?php echo e($players->firstWhere('id', $event->player_id)->name); ?>

                            <?php if(auth()->user() != null && auth()->user()->is_admin && !$game->finished): ?>
                                
                                <form action="<?php echo e(route('events.destroy', ['event' => $event->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="ml-10 inline-block p-2 bg-sky-700 hover:bg-sky-900 text-white">Törlés</button>
                                </form>
                                
                            <?php endif; ?>
                        </div>
                        <br>
                        
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
            <p class=" text-3xl border border-gray-300 rounded-md divide-y divide-gray-300 text-center">Még nem kezdődött el</p>
        <?php endif; ?>
    </div>
    <?php if($game->start < now() && !$game->finished && auth()->user() != null && auth()->user()->is_admin): ?>
        <div class="text-center">
            <h1 class="mt-4">Új esemény hozzáadaása</h1>
            <form class="mt-4" action="<?php echo e(route('events.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                Perc: <input class="mt-4" id="minute" type="text" name="minute" value="<?php echo e(old('minute')); ?>"><br>
                <?php $__errorArgs = ['minute'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?><br>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                Esemény:
                <select class="mt-4" id="type" name="type">
                    <option value="gól">Gól</option>
                    <option value="öngól">Öngól</option>
                    <option value="sárga lap">Sárga lap</option>
                    <option value="piros lap">Piros lap</option>
                  </select><br>
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?><br>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                Játékos: 
                <select class="mt-4" id="player" name="player">
                    <?php $__currentLoopData = ($game->homeTeam->players->sortBy('number')->concat($game->awayTeam->players->sortBy('number'))); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <option value="<?php echo e($player->id); ?>"><?php echo e($player->team->name); ?> | <?php echo e($player->number); ?> | <?php echo e($player->name); ?></option>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <?php $__errorArgs = ['player'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?><br>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input value="<?php echo e($game->id); ?>" name="passGame" type="hidden">
                <button  type="submit" class="mt-4 inline-block p-2 bg-sky-700 hover:bg-sky-900 text-white">Mentés</button>
            </form>
        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\A Suli\Szerveroldali\football_championship\resources\views/games/show.blade.php ENDPATH**/ ?>