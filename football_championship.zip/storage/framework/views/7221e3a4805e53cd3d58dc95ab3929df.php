<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bg-gray-200' => true]); ?>
    <?php
        $counter = 1;
    ?>
    <h1 class="text-center">Tabella</h1>
    <table class="table-auto w-full">
        <thead>
          <tr>
            <th class="px-4 py-2 text-left">Csapat</th>
            <th class="px-4 py-2 text-left">Lőtt gólok</th>
            <th class="px-4 py-2 text-left">Kapott gólok</th>
            <th class="px-4 py-2 text-left">Gól különbség</th>
            <th class="px-4 py-2 text-left">Pontszám</th>
            <th class="px-4 py-2 text-left">Helyezés</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $standings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="border-b-2 border-gray-200 hover:bg-gray-100">
            <td class="px-4 py-2"><?php echo e($team['name']); ?></td>
            <td class="px-4 py-2"><?php echo e($team['scored'] ?? ""); ?></td>
            <td class="px-4 py-2"><?php echo e($team['conceded'] ?? ""); ?></td>
            <td class="px-4 py-2"><?php echo e($team['diff'] ?? ""); ?></td>
            <td class="px-4 py-2"><?php echo e($team['points'] ?? ""); ?></td>
            <td class="px-4 py-2"><?php echo e($counter); ?></td>
            <?php
                $counter++;
            ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\A Suli\Szerveroldali\football_championship\resources\views/tabella.blade.php ENDPATH**/ ?>